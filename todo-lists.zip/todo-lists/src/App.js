import React from 'react';
import TodeLists from './pages/todoLists'

function App() {
	return (
		<div className="app">
			<TodeLists />
		</div>
    );
}

export default App;
