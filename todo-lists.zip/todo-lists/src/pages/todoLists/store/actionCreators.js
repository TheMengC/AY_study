import * as types from './actionTypes'

/**
* @description 记录输入框输入的值
* @author SMC
* @date 2020-05-26
* @param {*} event
*/
export const searchNameValue = (e) => {
    let value = e.target.value
    return {type: types.SET_SEARCH_NAME,value}
}

/**
* @description 搜索功能
* @author SMC
* @date 2020-05-26
* @param {*} searchValue 搜索的名字
* @param {*} todoLists  展示的数组
*/
export const handleSearchValue = (searchValue, allLists) => {
    let pageLists = []
    if (searchValue) {
        pageLists = allLists.filter(item => {
            if (item.indexOf(searchValue) > -1) {
                return item
            }   
        })
    } else {
        pageLists = allLists
    }
    return {type: types.HANDLE_SEARCH_VALUE, pageLists}
}

/**
* @description 记录输入框输入的值
* @author SMC
* @date 2020-05-26
* @param {*} event
*/
export const setListValue = (e) => {
    let value = e.target.value
    return {type: types.SET_LIST_VALUE,value}
}

/**
* @description 将输入框的值添加到数组中
* @author SMC
* @date 2020-05-26
* @param {*} addValue 输入框的值
* @param {*} todoLists 总数组
*/
export const handleAddValue = (addValue, todoLists) => {
    let lists = []
    if (addValue) {
        lists = [...todoLists, addValue]
        addValue = ""
    }
    return {type: types.HANDLE_ADD_VALUE, lists, addValue}
}

/**
* @description 记录第一个输入框输入的值
* @author SMC
* @date 2020-05-26
* @param {*} event
*/
export const setValueOne = (e) => {
    let value = e.target.value
    return {type: types.SET_VALUE_ONE, value}
}

/**
* @description 记录第二个输入框输入的值
* @author SMC
* @date 2020-05-26
* @param {*} event
*/
export const setValueTwo = (e) => {
    let value = e.target.value
    return {type: types.SET_VALUE_TWO, value}
}

/**
* @description 记录第三个输入框输入的值
* @author SMC
* @date 2020-05-26
* @param {*} event
*/
export const setValueThree = (e) => {
    let value = e.target.value
    return {type: types.SET_VALUE_THREE, value}
}

/**
* @description 将输入框的值添加到数组中
* @author SMC
* @date 2020-05-26
* @param {*} one 第一个输入框的值
* @param {*} two 第二个输入框的值
* @param {*} three 第三个输入框的值
* @param {*} todoLists 总数组
*/
export const handleThreeMsg = (one, two, three, todoLists) => {
    console.log(one, two, three)
    let list = []
    if (one) {
        list = [...list, one]
        one = "";
    }
    if (two) {
        list = [...list, two];
        two = "";
    }
    if (three) {
        list = [...list, three];
        three = ""
    }
    console.log(list)
    let arrList = [...todoLists, ...list]
    return {type: types.HANDLE_THREE_MSG, one, two, three, arrList}
}
