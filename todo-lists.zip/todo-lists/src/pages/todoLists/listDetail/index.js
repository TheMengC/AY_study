import React, { Component } from 'react'
import './index.css'

import Search from './search'
import AddLists from './addLists'
import Content from './content'

class ListDetail extends Component {


    render() {
        return (
            <div className="list-detail">
                <Search />
                <AddLists />
                <Content />
            </div>
        )
    }
}

export default ListDetail