import React, { Component } from 'react';
import './index.css'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as actionCreators from 'pages/todoLists/store/actionCreators'

class Content extends Component {

    render() {
        const { todoLists} = this.props
        return (
            <div className="content">
                <div className="user-information">
                    {
                        todoLists.map((item, index) => {
                            return (
                                <div className="information" key={index}>
                                    <div className="name">{item}</div>
                                    <div className="over" >完成</div>
                                    <div className="change" >编辑</div>
                                    <div className="detele" >删除</div>
                                </div>
                            )
                        })
                    }
                </div>

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        todoLists: state.todoLists.todoLists,
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(actionCreators, dispatch)
}


export default connect(mapStateToProps, mapDispatchToProps)(Content)